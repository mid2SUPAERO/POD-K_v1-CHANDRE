Gaussian process from scikit learn <0.18
ONERA add some functions to the class GaussianProcess defined in gaussian_process.py
(4 functions added (conditioned_covariance_function, random_trajectories, KL_expansion, eval_KL_vect))
