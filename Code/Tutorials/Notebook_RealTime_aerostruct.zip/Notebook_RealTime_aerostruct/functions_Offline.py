import numpy as np
from PARAM_WING_VLM_FEM import PARAM_WING_VLM_FEM
from mesh_deformation_airbus import mesh_deformation_airbus
from VLM import VLM_study
from FEM import FEM_study
from transfert import transfert_matrix



"""
Definition of a function which runs the solver aero_struct
"""
def run_aerostruct(param_data,b,S,phi,diedre,BF,Mach):
    #1) Applying the right values in the wing
    a_new = mesh_deformation_airbus('param_wing/VLM_mesh.msh','param_wing/FEM_mesh.msh') 
    a_new.new_wing_mesh(b,S,phi,diedre,BF,Mach)
    #2) Defining the files used and the parameters
    vlm_mesh_file = 'param_wing/new_VLM.msh'
    vlm_mesh_file_out = 'param_wing/new_VLM_def.msh'
    fem_mesh = 'param_wing/new_FEM.msh'
    #3) Performing the analysis and saving the results
    pw = PARAM_WING_VLM_FEM(param_data)
    U,gamma = pw.do_analysis(vlm_mesh_file,vlm_mesh_file_out,fem_mesh)
    return U, gamma

"""
Definition of a function which returns the fields needed to compute the RB-VLM parameters
"""
def VLM_params(param_data,b,S,phi,diedre,BF,Mach):
    #1) Applying the right values in the wing
    a_new = mesh_deformation_airbus('param_wing/VLM_mesh.msh','param_wing/FEM_mesh.msh') 
    a_new.new_wing_mesh(b,S,phi,diedre,BF,Mach)
    #2) Defining the files used and the parameters
    vlm_mesh_file = 'param_wing/new_VLM.msh'
    #3) Performing the analysis and saving the results
    vlm_part = VLM_study(vlm_mesh_file,alpha = param_data[0],v_inf = param_data[1],rho = param_data[2])
    A = vlm_part.get_A()
    B = vlm_part.get_B()
    return A, B

"""
Definition of a function which returns the Strucutural Force
"""
def get_Fs(gamma,param_data):
    vlm_mesh_file = 'param_wing/new_VLM.msh'
    fem_mesh = 'param_wing/new_FEM.msh'
    my_vlm = VLM_study(vlm_mesh_file,alpha = param_data[0],v_inf = param_data[1],rho = param_data[2])
    my_pw = PARAM_WING_VLM_FEM(param_data)
    Fa = my_vlm.compute_forces_ROB(gamma)
    vlm_nodes,fem_nodes = my_pw.get_nodes(fem_mesh,my_vlm)
    H = transfert_matrix(fem_nodes,vlm_nodes,function_type='thin_plate')
    F_a = my_vlm.compute_force_at_nodes(vlm_nodes,Fa)
    Fs = np.dot(H.T,F_a)
    return Fs

def get_FEM(param_data,F_s):
    vlm_mesh_file = 'param_wing/new_VLM.msh'
    my_vlm = VLM_study(vlm_mesh_file,alpha = param_data[0],v_inf = param_data[1],rho = param_data[2])
    element_property,material,element_type = create_dict(param_data)
    fem_mesh = 'param_wing/new_FEM.msh'
    my_fem = FEM_study(fem_mesh,element_type,element_property,material)
    elem_dict,element_tot = my_fem.read_mesh_file()
    fem_nodes_tot = elem_dict['nodes'].copy()
    elm_skins = elem_dict['element_sets'][1]['elements']
    node_skins = np.unique(elm_skins[:,3:6])
    node_skins = np.array(node_skins,dtype = int)
    fem_nodes_ind = node_skins
    my_fem.assembling_K()
    #creating the rhs for the fem study
    rhs = np.zeros((len(fem_nodes_tot)*6,))
    for i in range(3):
        rhs[6*(fem_nodes_ind-1)+i] = F_s[:,i]
    my_fem.set_rhs(rhs)    
    #Boundary condition
    my_pw = PARAM_WING_VLM_FEM(param_data)
    _,fem_nodes = my_pw.get_nodes(fem_mesh,my_vlm)
    ind = fem_nodes[:,1]<=0.06
    nodes_sets = [fem_nodes_ind[ind]]
    dof = [[0,1,2,3,4,5]]
    my_fem.boundary_conditions(nodes_sets,dof)
    K = my_fem.get_K()
    Fs = my_fem.get_rhs()
    return K, Fs

"""
Definition of a function which creates the dictionaries needed for beginning the FEM analysis
"""
def create_dict(param_data):
    element_property = {'tri':{'"skins"':{'h':param_data[5]},'"ribs"':{'h':param_data[6]},
                                   '"spars_le"':{'h':param_data[7]},'"spars_te"':{'h':param_data[8]}}}
    material = {'tri':{'"skins"':{'E':param_data[3],'nu':param_data[4]},'"ribs"':{'E':param_data[3],'nu':param_data[4]},
                       '"spars_le"':{'E':param_data[3],'nu':param_data[4]},'"spars_te"':{'E':param_data[3],'nu':param_data[4]}}}
    element_type = {'tri':'DKT'}
    return element_property,material,element_type